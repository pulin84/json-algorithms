package sf.businessevents.helper;

import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

@Component
public class JsonCaseInSensitiveHelper {


	public JSONObject getJsonObjectByIgnoringCase(JSONObject input, String key) {

		Iterator<String> iter = input.keySet().iterator();
		while (iter.hasNext()) {
			String key1 = iter.next();
			if (key1.equalsIgnoreCase(key)) {
				return input.getJSONObject(key1);
			}
		}

		return null;

	}

	public String getValueByIgnoringCase(JSONObject input, String key) {

		Iterator<String> iter = input.keySet().iterator();
		while (iter.hasNext()) {
			String key1 = iter.next();
			if (key1.equalsIgnoreCase(key)) {
				return (String) input.get(key1);
			}
		}

		return null;

	}

	public org.json.JSONArray getJsonArrayByIgnoringCase(JSONObject input, String key) {

		Iterator<String> iter = input.keySet().iterator();
		while (iter.hasNext()) {
			String key1 = iter.next();
			if (key1.equalsIgnoreCase(key)) {
				return input.getJSONArray(key1);
			}
		}
		return null;

	}

	public Object getObjectByIgnoringCase(JSONObject input, String key) {

		Iterator<String> iter = input.keySet().iterator();
		while (iter.hasNext()) {
			String key1 = iter.next();
			
			if (key1.equalsIgnoreCase(key)) {
				return input.get(key1);
			}
		}
		return null;
	}
	
	public JSONObject convertJsonKeysLowerCase(JSONObject jsonObject) throws JSONException {
		JSONObject resultJsonObject = new JSONObject();
		Iterator<String> keys = jsonObject.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			Object value = null;
			try {
				JSONObject nestedJsonObject = jsonObject.getJSONObject(key);
				value = this.convertJsonKeysLowerCase(nestedJsonObject);
			} catch (JSONException jsonException) {
				value = jsonObject.get(key);
				if (value instanceof org.json.JSONArray) {
					org.json.JSONArray arr = (org.json.JSONArray) value;
					value = this.convertJsonKeysLowerCase(arr);
				}
			}
			resultJsonObject.put(key.toLowerCase(), value);
		}

		return resultJsonObject;
	}

	private org.json.JSONArray convertJsonKeysLowerCase(org.json.JSONArray jsonArray) {
		org.json.JSONArray arr = new org.json.JSONArray();
		jsonArray.forEach(a -> {
			if (a instanceof JSONObject) {
				arr.put(this.convertJsonKeysLowerCase((JSONObject) a));
			}
		});
		return arr;
	}

}

package sf.businessevents.service;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;

import sf.businessevents.constants.ApplicationConstants;
import sf.businessevents.helper.JsonPathExpressionHelper;

@Component
public class JsonResponseBuilderService {

	// @Autowired
	// private JsonNavigationHelper jsonNavigationHelper;

	@Autowired
	private JsonPathExpressionHelper jsonPathExpressionHelper;

	public Map<String, List<String>> createOutputJsonPathValuesMap(JSONObject inputJson,
			Map<String, String> outputInputMap) {
		Map<String, List<String>> responseMap = Maps.newHashMap();
		outputInputMap = new TreeMap<>(outputInputMap);

		// inputJson = jsonNavigationHelper.getJSONObjectOnelevelDeep(inputJson);
		Map<String, Integer> jsonElementArrayCountMap = new HashMap<>();
		
		int riskCount = 0;
		
		for (Entry<String, String> item : outputInputMap.entrySet()) {

			String outputJsonPath = item.getKey();
			String inputJsonPath = item.getValue();
			if (inputJsonPath.equals("businesseventdto.lineofbusinesstext")) {
				System.out.println();
			}

			List<String> attributeValues = jsonPathExpressionHelper.getAttributeValuesByJsonPath(inputJson,
					inputJsonPath);
			
			if (inputJsonPath.contains("risks") && !inputJsonPath.contains("rules")) {
				riskCount = riskCount > attributeValues.size() ? riskCount : attributeValues.size();
			}
			
			if (inputJsonPath.contains("risks") && inputJsonPath.contains("rules")) {
				int ruleCount = attributeValues.size() / riskCount;
				attributeValues = attributeValues.subList(0, ruleCount);
			}

			int numberOfWildcardArray = StringUtils.countMatches(outputJsonPath,
					ApplicationConstants.ARRAY_WITHOUT_INDEX);

			ArrayDeque<String> parentJsonPaths = new ArrayDeque<>();

			if (numberOfWildcardArray > 0) {
				String ultimateProperty = StringUtils.substringAfterLast(outputJsonPath,
						ApplicationConstants.ARRAY_WITHOUT_INDEX);
				String[] splittedArray = StringUtils.split(outputJsonPath, ApplicationConstants.ARRAY_WITHOUT_INDEX);
				StringBuilder jsonPathBuilder = new StringBuilder();

				for (int i = 0; i < splittedArray.length - 1; i++) {
					String splittedArrayItem = splittedArray[i];

					jsonPathBuilder.append(splittedArrayItem + ApplicationConstants.ARRAY_WITHOUT_INDEX);

					if (numberOfWildcardArray != 1 && jsonElementArrayCountMap.get(jsonPathBuilder.toString()) != null
							&& ultimateProperty.equals(splittedArray[i + 1])) {
						addToResponseMap(responseMap, attributeValues, parentJsonPaths, ultimateProperty,
								splittedArrayItem, numberOfWildcardArray);
						break;
					}

					if (jsonElementArrayCountMap.get(jsonPathBuilder.toString()) != null) {

						int parentArrayCount = jsonElementArrayCountMap.get(jsonPathBuilder.toString());

						if (parentJsonPaths.isEmpty()) {
							addToResponseMapSingleWildArray(responseMap, attributeValues, parentJsonPaths,
									ultimateProperty, splittedArray, i, splittedArrayItem, parentArrayCount);
						} else {
							addToParentJsonArrayDeque(parentJsonPaths, splittedArrayItem, parentArrayCount);
						}
					} else {
						jsonElementArrayCountMap.put(jsonPathBuilder.toString(), attributeValues.size());
						addToResponseMap(responseMap, attributeValues, parentJsonPaths, ultimateProperty,
								splittedArrayItem, numberOfWildcardArray);
					}
				}
			} else {
				responseMap.put(outputJsonPath, attributeValues);
			}

		}

		return responseMap;
	}

	private void addToResponseMapSingleWildArray(Map<String, List<String>> responseMap, List<String> attributeValues,
			ArrayDeque<String> parentJsonPaths, String ultimateProperty, String[] splittedArray, int i,
			String splittedArrayItem, int parentArrayCount) {
		for (int j = 0; j < parentArrayCount; j++) {
			parentJsonPaths.add(splittedArrayItem + "[" + j + "]");
			if (ultimateProperty.equals(splittedArray[i + 1])) {
				String x1 = splittedArrayItem + "[" + j + "]" + ultimateProperty;
				responseMap.put(x1, Collections.singletonList(attributeValues.get(j)));
			}
		}
	}

	private void addToParentJsonArrayDeque(ArrayDeque<String> parentJsonPaths, String splittedArrayItem,
			int parentArrayCount) {
		int parentSizePathsCount = parentJsonPaths.size();

		for (int k = 0; k < parentSizePathsCount; k++) {
			String poppedItem = parentJsonPaths.pop();
			for (int j = 0; j < parentArrayCount; j++) {
				parentJsonPaths.add(poppedItem + splittedArrayItem + "[" + j + "]");
			}
		}
	}

	private void addToResponseMap(Map<String, List<String>> responseMap, List<String> attributeValues,
			ArrayDeque<String> parentJsonPaths, String ultimateProperty, String splittedArrayItem,
			Integer numberOfWildcardArray) {
		for (int j = 0; j < attributeValues.size(); j++) {
			if (numberOfWildcardArray == 1) {
				responseMap.put(splittedArrayItem + "[" + j + "]" + ultimateProperty,
						Collections.singletonList(attributeValues.get(j)));
			} else {
				for (String parentPath : parentJsonPaths) {
					String outputPath = parentPath + splittedArrayItem + "[" + j + "]" + ultimateProperty;
					responseMap.put(outputPath, Collections.singletonList(attributeValues.get(j)));
				}
			}
		}
	}

}

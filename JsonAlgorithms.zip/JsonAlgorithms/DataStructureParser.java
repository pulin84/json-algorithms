package sf.businessevents.helper;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

@Service
public class DataStructureParser {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DataStructureParser.class);
	
	public String validateAndConvertConsumerPayload(String consumerPayload) {
		 String json = null;
		try {
	    	consumerPayload = consumerPayload.trim().replaceFirst("^([\\W]+)<","<");
	        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(consumerPayload)));
	        String filteredXMLpayload = removeAttributesXML(document);
	        json = transformToJson(filteredXMLpayload);
	    } catch (Exception e) {
	    	LOGGER.error("Unable to parse the inputPayload", e);
	    	throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
	    }
		return json;
	}
	
	private String removeAttributesXML(Document document){
		visitAndRemoveAttributes(document, 0);
		DOMSource domSource = new DOMSource(document);
	    StringWriter writer = new StringWriter();
	    StreamResult result = new StreamResult(writer);
	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer transformer;
		try {
			transformer = tf.newTransformer();
		    transformer.transform(domSource, result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return writer.toString();
	}

	private static void visitAndRemoveAttributes(Node node, int level) {
		NodeList list = node.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node childNode = list.item(i);
			while(childNode.getAttributes() != null && childNode.getAttributes().getLength() > 0 ) {
				Node att = childNode.getAttributes().item(0);
				childNode.getAttributes().removeNamedItem(att.getNodeName());
			}
			visitAndRemoveAttributes(childNode, level + 1);
		}
	}
	
	private String transformToJson(String consumerPayload) {
	    JSONObject json = XML.toJSONObject(consumerPayload, true);
		return json.toString();
	}
}

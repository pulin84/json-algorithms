package sf.businessevents.helper;

import java.util.Iterator;
import java.util.List;

import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.JsonPath;

import net.minidev.json.JSONArray;
import sf.businessevents.constants.ApplicationConstants;

@Component
public class JsonPathExpressionHelper {

	
	public List<String> getAttributeValuesByJsonPath(JSONObject inputJson, String jsonPath) {
		JSONArray obj = JsonPath.read(inputJson.toString(),
				ApplicationConstants.JSONPATH_SEPARATOR + jsonPath, new Criteria[] {});
		return jsonArrayToList(obj);
	}

	private List<String> jsonArrayToList(JSONArray obj) {
		JSONArray array = (JSONArray) obj;
		List<String> list = Lists.newArrayList();
		Iterator<Object> iterator = array.iterator();
		while (iterator.hasNext()) {
			Object item = iterator.next();
			/*if (item instanceof JSONArray) {
				list.addAll(jsonArrayToList((JSONArray) item));
			} else {*/
				list.add((String) item);
			/*}*/
		}
		return list;

	}

}

package sf.businessevents.helper;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.server.ResponseStatusException;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Component
public class FireEnterpriseInputBuilder {

	@Autowired
	private FireJsonBuilder jsonBuilder;
	
	
	private Map<String, String> buildListWithElements(){
		Map<String, String> map = Maps.newHashMap();
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.associateOrganizationTypeName", "Individual");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.associateRoleNameText", "Servicing");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.businessLineName", "Fire");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.customerRoleNameText", "Requestor");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.workflowName", "Manage Acquisition");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.derivedEventIndicator", "R");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.sourceChannelName", "");
		map.put("GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.businessRoleGroupName", "");
		map.put("GenericBusinessEventWrapper.FirePolicyEventHeaderEO.transactionTypeName", "New Business");
		return map;
	}
	

	public String buildFireEnterpriseInput(JSONObject jsonObject) {
		DocumentContext dc = JsonPath.parse(jsonObject);
		Map<String, String> map = buildListWithElements();
		map.keySet().forEach( item -> {
			jsonBuilder.buildJsonByJsonPath(jsonObject, item);
		});
		String accessChannelName = getAttributeValuesByJsonPath(jsonObject, "GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.AccessChannelName").stream().findFirst().orElse(null);
		
		setSourceChannelAndBusinessGroupName(map, accessChannelName);
		
		map.forEach((key, value) -> {
			setJSONProperty(jsonObject, value, key);
		});

		return ((JSONObject) dc.json()).toString(4);
	}
	
	private void setSourceChannelAndBusinessGroupName(Map<String, String> map, String accessChannelName) {
		String sourceChannelName = "GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.sourceChannelName";
		String businessRoleGroupName = "GenericBusinessEventWrapper.FireLegacyApplicationSubmittedEventPayloadEO.businessRoleGroupName";
		switch (accessChannelName.toUpperCase()) {
		case "OPERATIONS":
			map.put(sourceChannelName, "Associate");
			map.put(businessRoleGroupName, "operations");
			break;
		case "CCN":
			map.put(sourceChannelName, "Associate");
			map.put(businessRoleGroupName, "callCenter");

			break;
		case "AGENT":
			map.put(sourceChannelName, "Associate");
			map.put(businessRoleGroupName, "agent");
			break;
		default:
			throw new ResponseStatusException(HttpStatus.PRECONDITION_FAILED, "Value Not found for AccessChannelName");
		}
	}


	private JSONObject setJSONProperty(JSONObject outputJSON, String value, String outputPath) {
		String[] splittedOutputPathArr = outputPath.split("\\.");
		for (int i = 0; i < splittedOutputPathArr.length; i++) {

			String subPathNoArrayPattern = splittedOutputPathArr[i];
			
			Iterator<String> iterator = outputJSON.keys();
			String key = null;
			while (iterator.hasNext()) {
				key = (String) iterator.next();
				Object nestedJsonObject = outputJSON.get(key);
					if (ObjectUtils.isEmpty(nestedJsonObject) && key.equalsIgnoreCase(subPathNoArrayPattern)) {
						outputJSON.put(key, value);
						return outputJSON;
					}
				if (nestedJsonObject instanceof JSONObject && key.equalsIgnoreCase(subPathNoArrayPattern)) {
						outputJSON = outputJSON.getJSONObject(key);
						break;
				}
			}
		}
		return outputJSON;
	}

	public List<String> getAttributeValuesByJsonPath(JSONObject inputJson, String jsonPath) {
		net.minidev.json.JSONArray obj = JsonPath.read(inputJson.toString(),
				"." + jsonPath, new Criteria[] {});
		return jsonArrayToList(obj);
	}

	private List<String> jsonArrayToList(net.minidev.json.JSONArray obj) {
		net.minidev.json.JSONArray array = (net.minidev.json.JSONArray) obj;
		List<String> list = Lists.newArrayList();
		Iterator<Object> iterator = array.iterator();
		while (iterator.hasNext()) {
			Object item = iterator.next();
				list.add((String) item);
		}
		return list;

	}

}
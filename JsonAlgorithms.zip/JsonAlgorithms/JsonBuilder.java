package sf.businessevents.helper;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import sf.businessevents.constants.ApplicationConstants;


@Component
public class JsonBuilder {

	@Autowired
	private JsonCaseInSensitiveHelper jsonCaseInSensitiveHelper;

	public JSONObject buildJsonByJsonPath(JSONObject json, String jsonPath) {
		try {
			String[] splittedOutputPathArr = jsonPath.split("\\.");

			for (int indexNum = 0; indexNum < splittedOutputPathArr.length; indexNum++) {
				String subPath = splittedOutputPathArr[indexNum];
				checkAndAddMissingKeyToJson(json, splittedOutputPathArr, indexNum, subPath);
				Iterator<String> iterator = json.keys();

				String key = null;
				while (iterator.hasNext()) {
					key = (String) iterator.next();
					Object nestedJson = json.get(key);

					if (ObjectUtils.isEmpty(nestedJson) && key.equalsIgnoreCase(subPath)) {
						return json;
					}
					if (nestedJson instanceof JSONObject) {
						if ((key.equalsIgnoreCase(subPath))) {
							json = json.getJSONObject(key);
							break;
						}
					}
					if (nestedJson instanceof org.json.JSONArray) {
						String arrayItemNoArrayPattern = subPath.replaceAll(ApplicationConstants.ARRAY_PATTERN,
								StringUtils.EMPTY);
						if (key.equalsIgnoreCase(arrayItemNoArrayPattern)) {
							json = addMissingAttributesAndReturnArray(json, splittedOutputPathArr, indexNum, subPath,
									key);
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	private JSONObject addMissingAttributesAndReturnArray(JSONObject json, String[] splittedOutputPathArr, int indexNum,
			String subPath, String key) {
		org.json.JSONArray jArray = json.getJSONArray(key);
		Matcher m = arrayMatcher(subPath); // subPath must contain [#] in order to enter this method
		m.find(); // No obvious way for this to be false
		int arrayNumber = findArrayNumber(m.group());
		if (jArray.opt(arrayNumber) == null) {
			addMissingAttributesToArray(splittedOutputPathArr, indexNum, jArray, arrayNumber);
		}
		if (!ObjectUtils.isEmpty(jArray.get(arrayNumber))) {
			json = jArray.getJSONObject(arrayNumber);
		}

		return json;
	}

	private void checkAndAddMissingKeyToJson(JSONObject json, String[] splittedOutputPathArr, int indexNum,
			String subPath) {
		Matcher currentAttributeArrMatcher = arrayMatcher(subPath);
		String arrayFilteredPath = subPath;
		boolean currentAttrArrayFound = currentAttributeArrMatcher.find();
		if (currentAttrArrayFound) {
			arrayFilteredPath = arrayFilteredPath.replace(currentAttributeArrMatcher.group(), StringUtils.EMPTY);
		}

		if (jsonCaseInSensitiveHelper.getObjectByIgnoringCase(json, arrayFilteredPath) == null) {
			addMissingKeyToJson(json, splittedOutputPathArr, indexNum, arrayFilteredPath, currentAttrArrayFound);
		}
	}

	private void addMissingAttributesToArray(String[] splittedOutputPathArr, int indexNum, org.json.JSONArray jArray,
			int arrayNumber) {
		String innerElement = StringUtils.EMPTY;
		if (indexNum + 1 < splittedOutputPathArr.length) {
			innerElement = splittedOutputPathArr[indexNum + 1];
			Matcher innerElementArrMatcher = arrayMatcher(innerElement);
			if (innerElementArrMatcher.find()) {
				String innerElementarrayItemNoArrayPattern = innerElement.replaceAll(ApplicationConstants.ARRAY_PATTERN,
						StringUtils.EMPTY);
				JSONObject innerJson = new JSONObject();
				innerJson.put(innerElementarrayItemNoArrayPattern, new org.json.JSONArray());

				jArray.put(arrayNumber, innerJson);
			} else {
				jArray.put(arrayNumber, new JSONObject());

			}
		} else {
			jArray.put(arrayNumber, innerElement);
		}
	}

	private void addMissingKeyToJson(JSONObject json, String[] splittedOutputPathArr, int i, String arrayFilteredPath,
			boolean currentAttrArrayFound) {
		if (currentAttrArrayFound) {
			json.put(arrayFilteredPath, new org.json.JSONArray());
		} else {
			String innerElement = StringUtils.EMPTY;
			if (i + 1 < splittedOutputPathArr.length) {
				innerElement = splittedOutputPathArr[i + 1];
				Matcher innerElementArrMatcher = arrayMatcher(innerElement);
				if (!innerElementArrMatcher.find()) {
					json.put(arrayFilteredPath, new JSONObject());
				} else {
					json.put(arrayFilteredPath, new JSONObject());
				}
			} else {
				json.put(arrayFilteredPath, innerElement);
			}
		}

	}

	private Matcher arrayMatcher(String input) {
		Pattern p = Pattern.compile(ApplicationConstants.ARRAY_PATTERN);
		return p.matcher(input);
	}

	private int findArrayNumber(String input) {
		return (int) Integer.valueOf(input.substring(1, input.length() - 1));
	}
}

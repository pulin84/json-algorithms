package sf.businessevents.helper;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;


@Component
public class FireJsonBuilder {

	@Autowired
	private JsonHelper jsonHelper;

	public JSONObject buildJsonByJsonPath(JSONObject json, String jsonPath) {
		try {
			String[] splittedOutputPathArr = jsonPath.split("\\.");

			for (int indexNum = 0; indexNum < splittedOutputPathArr.length; indexNum++) {
				String subPath = splittedOutputPathArr[indexNum];
				checkAndAddMissingKeyToJson(json, splittedOutputPathArr, indexNum, subPath);
				Iterator<String> iterator = json.keys();

				String key = null;
				while (iterator.hasNext()) {
					key = (String) iterator.next();
					Object nestedJson = json.get(key);

					if (ObjectUtils.isEmpty(nestedJson) && key.equalsIgnoreCase(subPath)) {
						return json;
					}
					if (nestedJson instanceof JSONObject) {
						if ((key.equalsIgnoreCase(subPath))) {
							json = json.getJSONObject(key);
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	private void checkAndAddMissingKeyToJson(JSONObject json, String[] splittedOutputPathArr, int indexNum,
			String subPath) {
		String arrayFilteredPath = subPath;
		if (jsonHelper.getObjectByIgnoringCase(json, arrayFilteredPath) == null) {
			addMissingKeyToJson(json, splittedOutputPathArr, indexNum, arrayFilteredPath);
		}
	}

	private void addMissingKeyToJson(JSONObject json, String[] splittedOutputPathArr, int i, String arrayFilteredPath) {
			String innerElement = StringUtils.EMPTY;
			if (i + 1 < splittedOutputPathArr.length) {
				innerElement = splittedOutputPathArr[i + 1];
				Matcher innerElementArrMatcher = arrayMatcher(innerElement);
				if (!innerElementArrMatcher.find()) {
					json.put(arrayFilteredPath, new JSONObject());
				}
			} else {
				json.put(arrayFilteredPath, innerElement);
			}

	}

	private Matcher arrayMatcher(String input) {
		Pattern p = Pattern.compile("[*]");
		return p.matcher(input);
	}

}

package sf.businessevents.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import sf.businessevents.constants.ApplicationConstants;
import sf.businessevents.helper.JsonBuilder;

@Component
public class JsonTemplatePopulatorService {

	@Autowired
	private JsonBuilder jsonBuilder;

	public String buildAndPopulateJsonResponse(JSONObject outputJSON,
			Map<String, List<String>> inputOutputMap) {

		DocumentContext dc = JsonPath.parse(outputJSON);

//		outputJSON = jsonNavigationHelper.getJSONObjectOnelevelDeep(outputJSON);

		for (Entry<String, List<String>> item : inputOutputMap.entrySet()) {
			jsonBuilder.buildJsonByJsonPath(outputJSON, item.getKey());
		}

		for (Entry<String, List<String>> item : inputOutputMap.entrySet()) {
			setJSONProperty(outputJSON, item.getValue().isEmpty() ? "" : item.getValue().get(0), item.getKey());
		}
		outputJSON = dc.json();
		return outputJSON.toString(4);
	}

	private JSONObject setJSONProperty(JSONObject outputJSON, String value, String outputPath) {
		String[] splittedOutputPathArr = outputPath.split("\\.");
		for (int i = 0; i < splittedOutputPathArr.length; i++) {

			String subPath = splittedOutputPathArr[i];
			Matcher matcher = arrayMatcher(subPath);
			String subPathNoArrayPattern = subPath;
			boolean found = matcher.find();
			String matchedStr = "";
			
			if(found) {
				matchedStr = matcher.group();
				subPathNoArrayPattern = subPath.replace(matchedStr,"");
			}
			
			Iterator<String> iterator = outputJSON.keys();
			String key = null;
			while (iterator.hasNext()) {
				key = (String) iterator.next();
				Object nestedJsonObject = outputJSON.get(key);
					if (ObjectUtils.isEmpty(nestedJsonObject) && key.equalsIgnoreCase(subPathNoArrayPattern)) {
						outputJSON.put(key, value);
						return outputJSON;
					}
				if (nestedJsonObject instanceof JSONObject && key.equalsIgnoreCase(subPathNoArrayPattern)) {
						outputJSON = outputJSON.getJSONObject(key);
						break;
				}
				if (nestedJsonObject instanceof JSONArray && key.equalsIgnoreCase(subPathNoArrayPattern)) {
						JSONArray jArray = outputJSON.getJSONArray(key);
						if (found && jArray.length() > 0) {
							outputJSON = jArray.getJSONObject(findArrayNumber(matchedStr));
						}
						break;
				}
			}
		}
		return outputJSON;
	}

	private Matcher arrayMatcher(String input) {
		Pattern p = Pattern.compile(ApplicationConstants.ARRAY_PATTERN);
		return p.matcher(input);
	}

	private int findArrayNumber(String input) {
		return (int) Integer.valueOf(input.substring(1, input.length() - 1));
	}

}
